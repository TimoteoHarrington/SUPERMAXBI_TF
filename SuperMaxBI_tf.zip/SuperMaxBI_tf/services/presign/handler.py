import json
import os
import base64
import re
import boto3
from botocore.exceptions import BotoCoreError, ClientError

# ====== ENV VARS ======
BUCKET = os.environ.get("BUCKET_UPLOADS")           # p.ej. bucket de “archivos”
PREFIX = os.environ.get("UPLOAD_PREFIX", "sinprocesar/")  # carpeta destino
DEFAULT_CT = os.environ.get("DEFAULT_CONTENT_TYPE", "text/csv")

s3 = boto3.client("s3")


def lambda_handler(event, context):
    print("🟢 Event:", json.dumps(event))

    # ---- CORS preflight (REST API v1 y HTTP API v2) ----
    method = (
        (event.get("httpMethod"))                                  # REST v1
        or (event.get("requestContext", {}).get("http", {}).get("method"))  # HTTP v2
        or ""
    )
    if method.upper() == "OPTIONS":
        return _resp(200, {}, cors=True)

    # ---- Validaciones básicas ----
    if not BUCKET:
        return _resp(500, {"error": "Falta env BUCKET_UPLOADS"}, cors=True)

    try:
        body = json.loads(event.get("body") or "{}")
    except Exception:
        return _resp(400, {"error": "Body inválido (JSON)"}, cors=True)

    filename = body.get("filename")
    content_b64 = body.get("content")
    explicit_ct = body.get("contentType")  # opcional, si te lo manda el front

    if not filename or not content_b64:
        return _resp(400, {"error": "Faltan parámetros: filename y content"}, cors=True)

    # ---- Detección de tipo y key destino ----
    folder = _detect_file_type(filename)  # solo a modo informativo/log
    print(f"📁 Tipo detectado: {folder}")

    key = f"{PREFIX}{filename}" if PREFIX.endswith("/") else f"{PREFIX}/{filename}"
    content_type = explicit_ct or _guess_content_type(filename) or DEFAULT_CT

    # ---- Decodificar base64 y subir a S3 ----
    try:
        decoded = base64.b64decode(content_b64)
    except Exception as e:
        return _resp(400, {"error": f"content no es base64 válido: {e}"}, cors=True)

    try:
        s3.put_object(
            Bucket=BUCKET,
            Key=key,
            Body=decoded,
            ContentType=content_type,
        )
    except (BotoCoreError, ClientError) as e:
        print("❌ Error S3.put_object:", str(e))
        return _resp(500, {"error": str(e)}, cors=True)

    print(f"✅ Subido {filename} a s3://{BUCKET}/{key}")
    return _resp(200, {
        "status": "ok",
        "message": f"Archivo subido a s3://{BUCKET}/{key}",
        "key": key,
        "contentType": content_type,
    }, cors=True)


# ---------------- utils ----------------

def _detect_file_type(filename: str) -> str:
    """
    Determina el tipo según el nombre del archivo (para logging/telemetría).
    """
    name = filename.lower()
    if re.search(r"producto", name):
        return "productos"
    if re.search(r"venta", name):
        return "ventas"
    if re.search(r"sucursal", name):
        return "sucursales"
    return "otros"


def _guess_content_type(filename: str) -> str | None:
    """
    Inferir Content-Type simple por extensión.
    """
    name = filename.lower()
    if name.endswith(".csv"):
        return "text/csv"
    if name.endswith(".json"):
        return "application/json"
    if name.endswith(".txt"):
        return "text/plain"
    # imágenes comunes por si las usás
    if name.endswith(".png"):
        return "image/png"
    if name.endswith(".jpg") or name.endswith(".jpeg"):
        return "image/jpeg"
    return None


def _resp(status: int, body: dict, cors: bool = False):
    headers = {"Content-Type": "application/json"}
    if cors:
        headers.update({
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "OPTIONS,POST",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
        })
    return {
        "statusCode": status,
        "headers": headers,
        "body": json.dumps(body),
    }