import json
import os
import socket
import pg8000
from decimal import Decimal

# ====== ENV VARS ======
RS_HOST_RAW  = os.environ.get("RS_HOST", "")
RS_DB        = os.environ.get("RS_DB")
RS_USER      = os.environ.get("RS_USER")
RS_PASSWORD  = os.environ.get("RS_PASSWORD")
RS_PORT      = int(os.environ.get("RS_PORT", "5439"))
ALLOWED_ORIGIN = os.environ.get("ALLOWED_ORIGIN", "*")

# 🔧 Normalizar host (por si viene con :puerto)
RS_HOST = RS_HOST_RAW.split(":")[0] if RS_HOST_RAW else ""

# Defaults opcionales para filtros de fechas
DEFAULT_DATE_START = os.environ.get("DEFAULT_DATE_START", "2020-01-01")
DEFAULT_DATE_END   = os.environ.get("DEFAULT_DATE_END", "2030-12-31")

def lambda_handler(event, context):
    print("🟢 Event:", json.dumps(event))

    # --- CORS / Preflight ---
    method = (
        event.get("httpMethod")
        or event.get("requestContext", {}).get("http", {}).get("method")
        or ""
    ).upper()
    if method == "OPTIONS":
        return _resp(200, {"ok": True})

    # --- Validación de env vars mínimas ---
    missing = [k for k, v in {
        "RS_HOST": RS_HOST, "RS_DB": RS_DB, "RS_USER": RS_USER, "RS_PASSWORD": RS_PASSWORD
    }.items() if not v]
    if missing:
        return _resp(500, {"error": f"Faltan env vars: {', '.join(missing)}"})

    # --- Parámetros del querystring ---
    params        = event.get("queryStringParameters") or {}
    tabla         = (params.get("tabla") or "ventas").lower()
    sucursal_raw  = params.get("sucursal", "all")
    producto_raw  = params.get("producto", "all")
    fecha_inicio  = params.get("fecha_inicio", DEFAULT_DATE_START)
    fecha_fin     = params.get("fecha_fin", DEFAULT_DATE_END)

    # --- Sanity check de conectividad TCP (debug antes de conectar)
    try:
        socket.create_connection((RS_HOST, RS_PORT), timeout=3).close()
        print(f"✅ TCP OK hacia {RS_HOST}:{RS_PORT}")
    except Exception as e:
        print(f"❌ TCP FAIL hacia {RS_HOST}:{RS_PORT}: {e}")
        return _resp(500, {"error": "tcp_connect_fail", "detail": str(e)})

    try:
        conn = pg8000.connect(
            host=RS_HOST,
            database=RS_DB,
            user=RS_USER,
            password=RS_PASSWORD,
            port=RS_PORT,
            # pg8000 usa TLS por defecto si el servidor lo acepta; si tu versión requiere flag:
            # ssl=True,
        )
        cursor = conn.cursor()
        print("✅ Conexión a Redshift OK")

        if tabla == "productos":
            sql = """
                SELECT id_producto, nombre, descripcion, fecha_alta, fecha_baja
                FROM productos
                WHERE fecha_baja IS NULL OR fecha_baja > CURRENT_DATE
                ORDER BY id_producto
            """
            cursor.execute(sql)

        elif tabla == "categorias":
            sql = """
                SELECT id_categoria, nombre, descripcion
                FROM categorias
                ORDER BY id_categoria
            """
            cursor.execute(sql)

        elif tabla == "sucursales":
            sql = """
                SELECT id_sucursal, direccion, fecha_alta, fecha_baja
                FROM sucursales
                WHERE fecha_baja IS NULL OR fecha_baja > CURRENT_DATE
                ORDER BY id_sucursal
            """
            cursor.execute(sql)

        elif tabla == "ventas":
            sql = """
                SELECT
                    v.id_venta,
                    v.id_sucursal,
                    v.id_producto,
                    v.fecha,
                    v.cantidad,
                    v.precio_unitario,
                    p.id_categoria
                FROM ventas v
                LEFT JOIN productos p ON v.id_producto = p.id_producto
                WHERE v.fecha BETWEEN %s AND %s
            """
            query_params = [fecha_inicio, fecha_fin]
            if sucursal_raw != "all":
                sql += " AND v.id_sucursal = %s"
                query_params.append(int(sucursal_raw))
            if producto_raw != "all":
                sql += " AND v.id_producto = %s"
                query_params.append(int(producto_raw))
            sql += " ORDER BY v.fecha DESC"
            print("🔍 SQL:", sql)
            print("🔍 Params:", query_params)
            cursor.execute(sql, query_params)

        else:
            return _resp(400, {"error": f"Tabla no soportada: {tabla}"})

        rows = cursor.fetchall()
        cols = [c[0] for c in cursor.description] if cursor.description else []
        data = [_row_to_dict(cols, r) for r in rows]

        return _resp(200, {
            "status": "ok",
            "tabla": tabla,
            "total": len(data),
            "registros": data,
        })

    except Exception as e:
        import traceback
        print("❌ Error:", e)
        print("❌ Traceback:", traceback.format_exc())
        return _resp(500, {"error": str(e)})

    finally:
        try:
            cursor.close()
            conn.close()
            print("🔌 Conexión cerrada.")
        except Exception:
            pass

# ---------------- helpers ----------------
def _resp(status: int, body: dict):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
            "Access-Control-Allow-Methods": "GET,OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token",
        },
        "body": json.dumps(body, default=_json_default, ensure_ascii=False),
    }

def _json_default(o):
    if isinstance(o, Decimal):
        return float(o)
    return str(o)

def _row_to_dict(columns, row):
    out = {}
    for i, col in enumerate(columns):
        v = row[i]
        if isinstance(v, Decimal):
            v = float(v)
        out[col] = v
    return out