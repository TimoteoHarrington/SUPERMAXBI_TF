import os, json, base64, urllib.parse, urllib.request, urllib.error

# ---------- helpers ----------
def _json(status: int, payload: dict):
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(payload),
        "isBase64Encoded": False,
    }

def _redirect(url: str):
    return {"statusCode": 302, "headers": {"Location": url}, "body": "", "isBase64Encoded": False}

def _get_redirect_uri(event):
    # Preferimos el valor fijo por env para evitar mismatches con Cognito
    env_uri = os.environ.get("REDIRECT_URI")
    if env_uri:
        return env_uri

    headers = event.get("headers") or {}
    host = headers.get("Host")
    proto = headers.get("X-Forwarded-Proto", "https")
    rc = event.get("requestContext") or {}
    stage = rc.get("stage") or ""
    path = event.get("rawPath") or event.get("path") or "/LambdaCallback"
    if not host:
        raise ValueError("Missing Host header from API Gateway")
    if not path.startswith("/"):
        path = "/" + path
    stage_part = f"/{stage}" if stage else ""
    return f"{proto}://{host}{stage_part}{path}"

# ---------- handler ----------
def lambda_handler(event, ctx):
    # Modo debug: devuelve lo que enviaríamos a Cognito (no canjea el code)
    DEBUG = (os.environ.get("DEBUG") == "1") or ((event.get("queryStringParameters") or {}).get("debug") == "1")

    # ENV VARS (requeridas)
    try:
        COGNITO_DOMAIN = os.environ["COGNITO_DOMAIN"].rstrip("/")
        CLIENT_ID      = os.environ.get("COGNITO_CLIENT_ID") or os.environ["CLIENT_ID"]
        FRONTEND_URL   = os.environ["FRONTEND_URL"]
        CLIENT_SECRET  = os.environ.get("COGNITO_CLIENT_SECRET")  # opcional para cliente confidencial
    except KeyError as e:
        return _json(500, {"error": "missing_env", "detail": f"Falta variable: {str(e)}"})

    # code de la URL
    params = event.get("queryStringParameters") or {}
    code = params.get("code")
    if not code:
        return _json(400, {"error": "missing_code", "detail": "Falta ?code= en la URL"})

    # redirect_uri (env o calculado)
    try:
        redirect_uri = _get_redirect_uri(event)
    except Exception as e:
        return _json(500, {"error": "redirect_uri_build_failed", "detail": str(e)})

    # Debug: mostrar exactamente qué vamos a mandar
    if DEBUG:
        return _json(200, {
            "debug": True,
            "token_url": f"{COGNITO_DOMAIN}/oauth2/token",
            "client_id": CLIENT_ID,
            "redirect_uri": redirect_uri,
            "frontend_url": FRONTEND_URL,
        })

    # Intercambio de tokens
    token_url = f"{COGNITO_DOMAIN}/oauth2/token"
    form = {
        "grant_type": "authorization_code",
        "client_id": CLIENT_ID,
        "redirect_uri": redirect_uri,
        "code": code,
    }
    data = urllib.parse.urlencode(form).encode("utf-8")

    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    if CLIENT_SECRET:  # App client confidencial
        basic = base64.b64encode(f"{CLIENT_ID}:{CLIENT_SECRET}".encode()).decode()
        headers["Authorization"] = f"Basic {basic}"

    try:
        req = urllib.request.Request(token_url, data=data, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as r:
            token = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode()
        except Exception:
            pass

        # Si el code fue reutilizado/expiró → redirigimos al login para que obtenga uno nuevo
        if e.code == 400 and "invalid_grant" in body:
            login_url = (
                f"{COGNITO_DOMAIN}/login"
                f"?client_id={urllib.parse.quote(CLIENT_ID)}"
                f"&response_type=code"
                f"&scope=openid+email+profile"
                f"&redirect_uri={urllib.parse.quote(redirect_uri, safe='')}"
            )
            return _redirect(login_url)

        # Otro error: devolvémoslo en claro (útil para operar)
        return _json(502, {
            "error": "token_http_error",
            "status": e.code,
            "reason": e.reason,
            "sent": {"client_id": CLIENT_ID, "redirect_uri": redirect_uri, "domain": COGNITO_DOMAIN},
            "body": body,
        })
    except Exception as e:
        return _json(500, {"error": "token_exchange_failed", "detail": str(e)})

    # OK: redirigimos al front con tokens en el fragmento
    idt = token.get("id_token")
    acc = token.get("access_token")
    if not idt:
        return _json(500, {"error": "no_id_token", "token_resp": token})

    fragment = urllib.parse.urlencode({"id_token": idt, "access_token": acc})
    return _redirect(f"{FRONTEND_URL}#{fragment}")