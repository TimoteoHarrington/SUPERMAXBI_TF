import os
import json
import csv
import tempfile
import boto3
import pg8000
import socket

# Variables de entorno definidas en Terraform
BUCKET            = os.environ["BUCKET"]
S3_PREFIX_SINPROC = os.environ.get("S3_PREFIX_SINPROC", "sinprocesar/")
S3_PREFIX_PROC    = os.environ.get("S3_PREFIX_PROC", "procesados/")

RS_HOST       = os.environ["RS_HOST"]
RS_DB         = os.environ.get("RS_DB", "supermax_dw")
RS_PORT       = int(os.environ.get("RS_PORT", "5439"))
RS_SECRET_ARN = os.environ["RS_SECRET_ARN"]

s3 = boto3.client("s3")
secrets = boto3.client("secretsmanager")

def _get_credentials(secret_arn):
    resp = secrets.get_secret_value(SecretId=secret_arn)
    secret_str = resp.get("SecretString")
    data = json.loads(secret_str)
    return data["username"], data["password"]

def lambda_handler(event, context):
    # Permite test manual (sin evento S3)
    if not event.get("Records"):
        key = f"{S3_PREFIX_SINPROC}soloprueba.csv"
    else:
        key = event["Records"][0]["s3"]["object"]["key"]

    # Descarga temporal del archivo
    tmp_path = os.path.join(tempfile.gettempdir(), os.path.basename(key))
    try:
        s3.download_file(BUCKET, key, tmp_path)
        print(f"Archivo descargado: s3://{BUCKET}/{key} -> {tmp_path}")
    except Exception as e:
        print(f"Error descargando {key}: {e}")
        return {"status": "error", "detalle": str(e)}

    # Validación de conectividad TCP (debug)
    try:
        print(f"🔌 Probando conexión TCP a {RS_HOST}:{RS_PORT} ...")
        with socket.create_connection((RS_HOST, RS_PORT), timeout=5):
            print("✅ Conexión TCP abierta exitosamente (Redshift reachable desde Lambda).")
    except Exception as e:
        print(f"❌ No se pudo abrir conexión TCP a {RS_HOST}:{RS_PORT} => {e}")
        return {"status": "error", "detalle": f"No se pudo abrir conexión TCP a Redshift: {e}"}

    # Validación de DNS
    try:
        ip = socket.gethostbyname(RS_HOST)
        print(f"🧠 Redshift DNS resolvió a IP: {ip}")
    except Exception as e:
        print(f"❌ No se pudo resolver DNS de Redshift: {e}")
        return {"status": "error", "detalle": f"No se pudo resolver DNS del cluster Redshift: {e}"}

    # Conexión real a Redshift
    try:
        user, pwd = _get_credentials(RS_SECRET_ARN)
        conn = pg8000.connect(
            host=RS_HOST,
            database=RS_DB,
            user=user,
            password=pwd,
            port=RS_PORT,
        )
        cursor = conn.cursor()
        print("Conexión a Redshift OK")
    except Exception as e:
        print(f"Error conectando a Redshift: {e}")
        return {"status": "error", "detalle": str(e)}

    # Lectura del CSV e inserción
    filas_insertadas = 0
    try:
        with open(tmp_path, newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            print(f"Columnas CSV: {reader.fieldnames}")
            for row in reader:
                cursor.execute("""
                    INSERT INTO public.ventas (id_sucursal, id_producto, fecha, cantidad, precio_unitario)
                    VALUES (%s, %s, %s, %s, %s)
                """, (
                    int(row['id_sucursal']) if row.get('id_sucursal') else None,
                    int(row['id_producto']) if row.get('id_producto') else None,
                    row.get('fecha'),
                    int(row['cantidad']) if row.get('cantidad') else None,
                    float(row['precio_unitario']) if row.get('precio_unitario') else None
                ))
                filas_insertadas += 1
        conn.commit()
        print(f"Se insertaron {filas_insertadas} filas en Redshift.")
    except Exception as e:
        conn.rollback()
        print(f"Error procesando CSV: {e}")
        return {"status": "error", "detalle": str(e)}
    finally:
        try:
            cursor.close()
            conn.close()
        except Exception:
            pass

    # Mover archivo a 'procesados/'
    try:
        nuevo_key = key.replace(S3_PREFIX_SINPROC, S3_PREFIX_PROC, 1)
        s3.copy_object(Bucket=BUCKET, CopySource={'Bucket': BUCKET, 'Key': key}, Key=nuevo_key)
        s3.delete_object(Bucket=BUCKET, Key=key)
        print(f"Movido a s3://{BUCKET}/{nuevo_key}")
    except Exception as e:
        print(f"Insertado pero error moviendo a 'procesados/': {e}")
        return {"status": "error", "detalle": f"Insertado pero no movido: {e}"}

    return {
        "status": "ok",
        "mensaje": f"{key} procesado. {filas_insertadas} filas insertadas y movido a {S3_PREFIX_PROC}"
    }
