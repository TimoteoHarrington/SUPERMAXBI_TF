INSERT INTO categorias (id_categoria, nombre, descripcion) VALUES
(1, 'Alimentos', 'Productos comestibles envasados o frescos'),
(2, 'Limpieza', 'Artículos para la limpieza del hogar'),
(3, 'Bebidas', 'Bebidas con o sin alcohol'),
(4, 'Higiene personal', 'Productos de cuidado personal y aseo'),
(5, 'Infancia', 'Productos para bebés y niños pequeños');

INSERT INTO productos (id_producto, id_categoria, nombre, descripcion, fecha_alta, fecha_baja) VALUES
(101, 1, 'Arroz Gallo Oro 1kg', 'Arroz largo fino de alta calidad', '2024-01-15', NULL),
(102, 2, 'Detergente Magistral 750ml', 'Detergente concentrado para vajilla', '2024-03-10', NULL),
(103, 3, 'Coca-Cola 1.5L', 'Gaseosa sabor cola botella plástica', '2023-11-01', NULL),
(104, 4, 'Shampoo Pantene 400ml', 'Shampoo para cabello dañado', '2024-02-01', NULL),
(105, 5, 'Pañales Pampers M x36', 'Pañales descartables talla M', '2024-04-20', NULL);

INSERT INTO precios (id_producto, valor, fecha_alta, fecha_baja) VALUES
(101, 1250.00, '2024-01-15', '2024-08-01'),
(101, 1380.00, '2024-08-02', NULL),
(102, 950.00,  '2024-03-10', NULL),
(103, 850.00,  '2023-11-01', '2024-07-01'),
(103, 920.00,  '2024-07-02', NULL),
(104, 1600.00, '2024-02-01', NULL),
(105, 5200.00, '2024-04-20', NULL);

INSERT INTO sucursales (id_sucursal, direccion, fecha_alta, fecha_baja) VALUES
(201, 'Av. Santa Fe 2450, CABA', '2023-10-01', NULL),
(202, 'Av. Rivadavia 8200, CABA', '2023-11-15', NULL),
(203, 'Mitre 500, Quilmes', '2024-01-05', NULL),
(204, 'Av. Maipú 1300, Vicente López', '2024-02-10', NULL),
(205, 'San Martín 450, San Isidro', '2024-03-01', NULL);