-- Crea objetos en la base supermax_dw (ya creada por Terraform)
CREATE TABLE IF NOT EXISTS categorias (
    id_categoria   BIGINT PRIMARY KEY,
    nombre         VARCHAR(100),
    descripcion    VARCHAR(500)
)
DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS precios (
    id_precio     BIGINT IDENTITY(1,1),
    id_producto   BIGINT,
    valor         DECIMAL(12,2),
    fecha_alta    DATE,
    fecha_baja    DATE,
    PRIMARY KEY (id_precio)
)
DISTKEY(id_producto)
SORTKEY(id_producto, fecha_alta);

CREATE TABLE IF NOT EXISTS sucursales (
    id_sucursal   BIGINT PRIMARY KEY,
    direccion     VARCHAR(150),
    fecha_alta    DATE,
    fecha_baja    DATE
)
DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS productos (
    id_producto   BIGINT PRIMARY KEY,
    id_categoria  BIGINT,
    nombre        VARCHAR(150),
    descripcion   VARCHAR(500),
    fecha_alta    DATE,
    fecha_baja    DATE
)
DISTSTYLE ALL;

CREATE TABLE IF NOT EXISTS ventas (
    id_venta        BIGINT IDENTITY(1,1),
    id_sucursal     BIGINT,
    id_producto     BIGINT,
    fecha           DATE,
    cantidad        INTEGER,
    precio_unitario DECIMAL(12,2),
    PRIMARY KEY (id_venta)
)
DISTKEY(id_producto)
SORTKEY(fecha);